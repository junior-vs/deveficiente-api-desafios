package vsj.deveficiente.api.casadocodigo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCasaDoCodigoApplicationTests {

	@Test
	void contextLoads() {
	}

}
