package vsj.deveficiente.api.casadocodigo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCasaDoCodigoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiCasaDoCodigoApplication.class, args);
	}

}
